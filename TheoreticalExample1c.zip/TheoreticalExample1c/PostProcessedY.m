% Rewriting the matrix W
VerifiedY11 = clean(replace(Y(1,1), coefList, double(coefList)), 0.001);
Y11 = sdisplay(VerifiedY11);

VerifiedY12 = clean(replace(Y(1,2), coefList, double(coefList)), 0.001);
Y12 = sdisplay(VerifiedY12);

VerifiedY13 = clean(replace(Y(1,3), coefList, double(coefList)), 0.001);
Y13 = sdisplay(VerifiedY13);

VerifiedY14 = clean(replace(Y(1,4), coefList, double(coefList)), 0.001);
Y14 = sdisplay(VerifiedY14);

VerifiedY15 = clean(replace(Y(1,5), coefList, double(coefList)), 0.001);
Y15 = sdisplay(VerifiedY15);

VerifiedY16 = clean(replace(Y(1,6), coefList, double(coefList)), 0.001);
Y16 = sdisplay(VerifiedY16);

VerifiedY17 = clean(replace(Y(1,7), coefList, double(coefList)), 0.001);
Y17 = sdisplay(VerifiedY17);

VerifiedY18 = clean(replace(Y(1,8), coefList, double(coefList)), 0.001);
Y18 = sdisplay(VerifiedY18);

VerifiedY19 = clean(replace(Y(1,9), coefList, double(coefList)), 0.001);
Y19 = sdisplay(VerifiedY19);

VerifiedY110 = clean(replace(Y(1,10), coefList, double(coefList)), 0.001);
Y110 = sdisplay(VerifiedY110);

VerifiedY111 = clean(replace(Y(1,11), coefList, double(coefList)), 0.001);
Y111 = sdisplay(VerifiedY111);

VerifiedY112 = clean(replace(Y(1,12), coefList, double(coefList)), 0.001);
Y112 = sdisplay(VerifiedY112);

VerifiedY21 = clean(replace(Y(2,1), coefList, double(coefList)), 0.001);
Y21 = sdisplay(VerifiedY21);

VerifiedY22 = clean(replace(Y(2,2), coefList, double(coefList)), 0.001);
Y22 = sdisplay(VerifiedY22);

VerifiedY23 = clean(replace(Y(2,3), coefList, double(coefList)), 0.001);
Y23 = sdisplay(VerifiedY23);

VerifiedY24 = clean(replace(Y(2,4), coefList, double(coefList)), 0.001);
Y24 = sdisplay(VerifiedY24);

VerifiedY25 = clean(replace(Y(2,5), coefList, double(coefList)), 0.001);
Y25 = sdisplay(VerifiedY25);

VerifiedY26 = clean(replace(Y(2,6), coefList, double(coefList)), 0.001);
Y26 = sdisplay(VerifiedY26);

VerifiedY27 = clean(replace(Y(2,7), coefList, double(coefList)), 0.001);
Y27 = sdisplay(VerifiedY27);

VerifiedY28 = clean(replace(Y(2,8), coefList, double(coefList)), 0.001);
Y28 = sdisplay(VerifiedY28);

VerifiedY29 = clean(replace(Y(2,9), coefList, double(coefList)), 0.001);
Y29 = sdisplay(VerifiedY29);

VerifiedY210 = clean(replace(Y(2,10), coefList, double(coefList)), 0.001);
Y210 = sdisplay(VerifiedY210);

VerifiedY211 = clean(replace(Y(2,11), coefList, double(coefList)), 0.001);
Y211 = sdisplay(VerifiedY211);

VerifiedY212 = clean(replace(Y(2,12), coefList, double(coefList)), 0.001);
Y212 = sdisplay(VerifiedY212);

VerifiedY31 = clean(replace(Y(3,1), coefList, double(coefList)), 0.001);
Y31 = sdisplay(VerifiedY31);

VerifiedY32 = clean(replace(Y(3,2), coefList, double(coefList)), 0.001);
Y32 = sdisplay(VerifiedY32);

VerifiedY33 = clean(replace(Y(3,3), coefList, double(coefList)), 0.001);
Y33 = sdisplay(VerifiedY33);

VerifiedY34 = clean(replace(Y(3,4), coefList, double(coefList)), 0.001);
Y34 = sdisplay(VerifiedY34);

VerifiedY35 = clean(replace(Y(3,5), coefList, double(coefList)), 0.001);
Y35 = sdisplay(VerifiedY35);

VerifiedY36 = clean(replace(Y(3,6), coefList, double(coefList)), 0.001);
Y36 = sdisplay(VerifiedY36);

VerifiedY37 = clean(replace(Y(3,7), coefList, double(coefList)), 0.001);
Y37 = sdisplay(VerifiedY37);

VerifiedY38 = clean(replace(Y(3,8), coefList, double(coefList)), 0.001);
Y38 = sdisplay(VerifiedY38);

VerifiedY39 = clean(replace(Y(3,9), coefList, double(coefList)), 0.001);
Y39 = sdisplay(VerifiedY39);

VerifiedY310 = clean(replace(Y(3,10), coefList, double(coefList)), 0.001);
Y310 = sdisplay(VerifiedY310);

VerifiedY311 = clean(replace(Y(3,11), coefList, double(coefList)), 0.001);
Y311 = sdisplay(VerifiedY311);

VerifiedY312 = clean(replace(Y(3,12), coefList, double(coefList)), 0.001);
Y312 = sdisplay(VerifiedY312);

VerifiedY41 = clean(replace(Y(4,1), coefList, double(coefList)), 0.001);
Y41 = sdisplay(VerifiedY41);

VerifiedY42 = clean(replace(Y(4,2), coefList, double(coefList)), 0.001);
Y42 = sdisplay(VerifiedY42);

VerifiedY43 = clean(replace(Y(4,3), coefList, double(coefList)), 0.001);
Y43 = sdisplay(VerifiedY43);

VerifiedY44 = clean(replace(Y(4,4), coefList, double(coefList)), 0.001);
Y44 = sdisplay(VerifiedY44);

VerifiedY45 = clean(replace(Y(4,5), coefList, double(coefList)), 0.001);
Y45 = sdisplay(VerifiedY45);

VerifiedY46 = clean(replace(Y(4,6), coefList, double(coefList)), 0.001);
Y46 = sdisplay(VerifiedY46);

VerifiedY47 = clean(replace(Y(4,7), coefList, double(coefList)), 0.001);
Y47 = sdisplay(VerifiedY47);

VerifiedY48 = clean(replace(Y(4,8), coefList, double(coefList)), 0.001);
Y48 = sdisplay(VerifiedY48);

VerifiedY49 = clean(replace(Y(4,9), coefList, double(coefList)), 0.001);
Y49 = sdisplay(VerifiedY49);

VerifiedY410 = clean(replace(Y(4,10), coefList, double(coefList)), 0.001);
Y410 = sdisplay(VerifiedY410);

VerifiedY411 = clean(replace(Y(4,11), coefList, double(coefList)), 0.001);
Y411 = sdisplay(VerifiedY411);

VerifiedY412 = clean(replace(Y(4,12), coefList, double(coefList)), 0.001);
Y412 = sdisplay(VerifiedY412);

VerifiedY51 = clean(replace(Y(5,1), coefList, double(coefList)), 0.001);
Y51 = sdisplay(VerifiedY51);

VerifiedY52 = clean(replace(Y(5,2), coefList, double(coefList)), 0.001);
Y52 = sdisplay(VerifiedY52);

VerifiedY53 = clean(replace(Y(5,3), coefList, double(coefList)), 0.001);
Y53 = sdisplay(VerifiedY53);

VerifiedY54 = clean(replace(Y(5,4), coefList, double(coefList)), 0.001);
Y54 = sdisplay(VerifiedY54);

VerifiedY55 = clean(replace(Y(5,5), coefList, double(coefList)), 0.001);
Y55 = sdisplay(VerifiedY55);

VerifiedY56 = clean(replace(Y(5,6), coefList, double(coefList)), 0.001);
Y56 = sdisplay(VerifiedY56);

VerifiedY57 = clean(replace(Y(5,7), coefList, double(coefList)), 0.001);
Y57 = sdisplay(VerifiedY57);

VerifiedY58 = clean(replace(Y(5,8), coefList, double(coefList)), 0.001);
Y58 = sdisplay(VerifiedY58);

VerifiedY59 = clean(replace(Y(5,9), coefList, double(coefList)), 0.001);
Y59 = sdisplay(VerifiedY59);

VerifiedY510 = clean(replace(Y(5,10), coefList, double(coefList)), 0.001);
Y510 = sdisplay(VerifiedY510);

VerifiedY511 = clean(replace(Y(5,11), coefList, double(coefList)), 0.001);
Y511 = sdisplay(VerifiedY511);

VerifiedY512 = clean(replace(Y(5,12), coefList, double(coefList)), 0.001);
Y512 = sdisplay(VerifiedY512);

VerifiedY61 = clean(replace(Y(6,1), coefList, double(coefList)), 0.001);
Y61 = sdisplay(VerifiedY61);

VerifiedY62 = clean(replace(Y(6,2), coefList, double(coefList)), 0.001);
Y62 = sdisplay(VerifiedY62);

VerifiedY63 = clean(replace(Y(6,3), coefList, double(coefList)), 0.001);
Y63 = sdisplay(VerifiedY63);

VerifiedY64 = clean(replace(Y(6,4), coefList, double(coefList)), 0.001);
Y64 = sdisplay(VerifiedY64);

VerifiedY65 = clean(replace(Y(6,5), coefList, double(coefList)), 0.001);
Y65 = sdisplay(VerifiedY65);

VerifiedY66 = clean(replace(Y(6,6), coefList, double(coefList)), 0.001);
Y66 = sdisplay(VerifiedY66);

VerifiedY67 = clean(replace(Y(6,7), coefList, double(coefList)), 0.001);
Y67 = sdisplay(VerifiedY67);

VerifiedY68 = clean(replace(Y(6,8), coefList, double(coefList)), 0.001);
Y68 = sdisplay(VerifiedY68);

VerifiedY69 = clean(replace(Y(6,9), coefList, double(coefList)), 0.001);
Y69 = sdisplay(VerifiedY69);

VerifiedY610 = clean(replace(Y(6,10), coefList, double(coefList)), 0.001);
Y610 = sdisplay(VerifiedY610);

VerifiedY611 = clean(replace(Y(6,11), coefList, double(coefList)), 0.001);
Y611 = sdisplay(VerifiedY611);

VerifiedY612 = clean(replace(Y(6,12), coefList, double(coefList)), 0.001);
Y612 = sdisplay(VerifiedY612);

Y = [Y11, Y12, Y13, Y14, Y15, Y16, Y17, Y18, Y19, Y110, Y111, Y112;
     Y21, Y22, Y23, Y24, Y25, Y26, Y27, Y28, Y29, Y210, Y211, Y212;
     Y31, Y32, Y33, Y34, Y35, Y36, Y37, Y38, Y39, Y310, Y311, Y312;
     Y41, Y42, Y43, Y44, Y45, Y46, Y47, Y48, Y49, Y410, Y411, Y412;
     Y51, Y52, Y53, Y54, Y55, Y56, Y57, Y58, Y59, Y510, Y511, Y512;
     Y61, Y62, Y63, Y64, Y65, Y66, Y67, Y68, Y69, Y610, Y611, Y612];
