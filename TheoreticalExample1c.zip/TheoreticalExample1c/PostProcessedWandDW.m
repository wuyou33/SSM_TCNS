% Rewriting the matrix W
VerifiedW11 = clean(replace(W(1,1), coefList, double(coefList)), 0.001);
W11 = sdisplay(VerifiedW11);

VerifiedW12 = clean(replace(W(1,2), coefList, double(coefList)), 0.001);
W12 = sdisplay(VerifiedW12);

VerifiedW13 = clean(replace(W(1,3), coefList, double(coefList)), 0.001);
W13 = sdisplay(VerifiedW13);

VerifiedW14 = clean(replace(W(1,4), coefList, double(coefList)), 0.001);
W14 = sdisplay(VerifiedW14);

VerifiedW15 = clean(replace(W(1,5), coefList, double(coefList)), 0.001);
W15 = sdisplay(VerifiedW15);

VerifiedW16 = clean(replace(W(1,6), coefList, double(coefList)), 0.001);
W16 = sdisplay(VerifiedW16);

VerifiedW17 = clean(replace(W(1,7), coefList, double(coefList)), 0.001);
W17 = sdisplay(VerifiedW17);

VerifiedW18 = clean(replace(W(1,8), coefList, double(coefList)), 0.001);
W18 = sdisplay(VerifiedW18);

VerifiedW19 = clean(replace(W(1,9), coefList, double(coefList)), 0.001);
W19 = sdisplay(VerifiedW19);

VerifiedW110 = clean(replace(W(1,10), coefList, double(coefList)), 0.001);
W110 = sdisplay(VerifiedW110);

VerifiedW111 = clean(replace(W(1,11), coefList, double(coefList)), 0.001);
W111 = sdisplay(VerifiedW111);

VerifiedW112 = clean(replace(W(1,12), coefList, double(coefList)), 0.001);
W112 = sdisplay(VerifiedW112);

VerifiedW21 = clean(replace(W(2,1), coefList, double(coefList)), 0.001);
W21 = sdisplay(VerifiedW21);

VerifiedW22 = clean(replace(W(2,2), coefList, double(coefList)), 0.001);
W22 = sdisplay(VerifiedW22);

VerifiedW23 = clean(replace(W(2,3), coefList, double(coefList)), 0.001);
W23 = sdisplay(VerifiedW23);

VerifiedW24 = clean(replace(W(2,4), coefList, double(coefList)), 0.001);
W24 = sdisplay(VerifiedW24);

VerifiedW25 = clean(replace(W(2,5), coefList, double(coefList)), 0.001);
W25 = sdisplay(VerifiedW25);

VerifiedW26 = clean(replace(W(2,6), coefList, double(coefList)), 0.001);
W26 = sdisplay(VerifiedW26);

VerifiedW27 = clean(replace(W(2,7), coefList, double(coefList)), 0.001);
W27 = sdisplay(VerifiedW27);

VerifiedW28 = clean(replace(W(2,8), coefList, double(coefList)), 0.001);
W28 = sdisplay(VerifiedW28);

VerifiedW29 = clean(replace(W(2,9), coefList, double(coefList)), 0.001);
W29 = sdisplay(VerifiedW29);

VerifiedW210 = clean(replace(W(2,10), coefList, double(coefList)), 0.001);
W210 = sdisplay(VerifiedW210);

VerifiedW211 = clean(replace(W(2,11), coefList, double(coefList)), 0.001);
W211 = sdisplay(VerifiedW211);

VerifiedW212 = clean(replace(W(2,12), coefList, double(coefList)), 0.001);
W212 = sdisplay(VerifiedW212);

VerifiedW31 = clean(replace(W(3,1), coefList, double(coefList)), 0.001);
W31 = sdisplay(VerifiedW31);

VerifiedW32 = clean(replace(W(3,2), coefList, double(coefList)), 0.001);
W32 = sdisplay(VerifiedW32);

VerifiedW33 = clean(replace(W(3,3), coefList, double(coefList)), 0.001);
W33 = sdisplay(VerifiedW33);

VerifiedW34 = clean(replace(W(3,4), coefList, double(coefList)), 0.001);
W34 = sdisplay(VerifiedW34);

VerifiedW35 = clean(replace(W(3,5), coefList, double(coefList)), 0.001);
W35 = sdisplay(VerifiedW35);

VerifiedW36 = clean(replace(W(3,6), coefList, double(coefList)), 0.001);
W36 = sdisplay(VerifiedW36);

VerifiedW37 = clean(replace(W(3,7), coefList, double(coefList)), 0.001);
W37 = sdisplay(VerifiedW37);

VerifiedW38 = clean(replace(W(3,8), coefList, double(coefList)), 0.001);
W38 = sdisplay(VerifiedW38);

VerifiedW39 = clean(replace(W(3,9), coefList, double(coefList)), 0.001);
W39 = sdisplay(VerifiedW39);

VerifiedW310 = clean(replace(W(3,10), coefList, double(coefList)), 0.001);
W310 = sdisplay(VerifiedW310);

VerifiedW311 = clean(replace(W(3,11), coefList, double(coefList)), 0.001);
W311 = sdisplay(VerifiedW311);

VerifiedW312 = clean(replace(W(3,12), coefList, double(coefList)), 0.001);
W312 = sdisplay(VerifiedW312);

VerifiedW41 = clean(replace(W(4,1), coefList, double(coefList)), 0.001);
W41 = sdisplay(VerifiedW41);

VerifiedW42 = clean(replace(W(4,2), coefList, double(coefList)), 0.001);
W42 = sdisplay(VerifiedW42);

VerifiedW43 = clean(replace(W(4,3), coefList, double(coefList)), 0.001);
W43 = sdisplay(VerifiedW43);

VerifiedW44 = clean(replace(W(4,4), coefList, double(coefList)), 0.001);
W44 = sdisplay(VerifiedW44);

VerifiedW45 = clean(replace(W(4,5), coefList, double(coefList)), 0.001);
W45 = sdisplay(VerifiedW45);

VerifiedW46 = clean(replace(W(4,6), coefList, double(coefList)), 0.001);
W46 = sdisplay(VerifiedW46);

VerifiedW47 = clean(replace(W(4,7), coefList, double(coefList)), 0.001);
W47 = sdisplay(VerifiedW47);

VerifiedW48 = clean(replace(W(4,8), coefList, double(coefList)), 0.001);
W48 = sdisplay(VerifiedW48);

VerifiedW49 = clean(replace(W(4,9), coefList, double(coefList)), 0.001);
W49 = sdisplay(VerifiedW49);

VerifiedW410 = clean(replace(W(4,10), coefList, double(coefList)), 0.001);
W410 = sdisplay(VerifiedW410);

VerifiedW411 = clean(replace(W(4,11), coefList, double(coefList)), 0.001);
W411 = sdisplay(VerifiedW411);

VerifiedW412 = clean(replace(W(4,12), coefList, double(coefList)), 0.001);
W412 = sdisplay(VerifiedW412);

VerifiedW51 = clean(replace(W(5,1), coefList, double(coefList)), 0.001);
W51 = sdisplay(VerifiedW51);

VerifiedW52 = clean(replace(W(5,2), coefList, double(coefList)), 0.001);
W52 = sdisplay(VerifiedW52);

VerifiedW53 = clean(replace(W(5,3), coefList, double(coefList)), 0.001);
W53 = sdisplay(VerifiedW53);

VerifiedW54 = clean(replace(W(5,4), coefList, double(coefList)), 0.001);
W54 = sdisplay(VerifiedW54);

VerifiedW55 = clean(replace(W(5,5), coefList, double(coefList)), 0.001);
W55 = sdisplay(VerifiedW55);

VerifiedW56 = clean(replace(W(5,6), coefList, double(coefList)), 0.001);
W56 = sdisplay(VerifiedW56);

VerifiedW57 = clean(replace(W(5,7), coefList, double(coefList)), 0.001);
W57 = sdisplay(VerifiedW57);

VerifiedW58 = clean(replace(W(5,8), coefList, double(coefList)), 0.001);
W58 = sdisplay(VerifiedW58);

VerifiedW59 = clean(replace(W(5,9), coefList, double(coefList)), 0.001);
W59 = sdisplay(VerifiedW59);

VerifiedW510 = clean(replace(W(5,10), coefList, double(coefList)), 0.001);
W510 = sdisplay(VerifiedW510);

VerifiedW511 = clean(replace(W(5,11), coefList, double(coefList)), 0.001);
W511 = sdisplay(VerifiedW511);

VerifiedW512 = clean(replace(W(5,12), coefList, double(coefList)), 0.001);
W512 = sdisplay(VerifiedW512);

VerifiedW61 = clean(replace(W(6,1), coefList, double(coefList)), 0.001);
W61 = sdisplay(VerifiedW61);

VerifiedW62 = clean(replace(W(6,2), coefList, double(coefList)), 0.001);
W62 = sdisplay(VerifiedW62);

VerifiedW63 = clean(replace(W(6,3), coefList, double(coefList)), 0.001);
W63 = sdisplay(VerifiedW63);

VerifiedW64 = clean(replace(W(6,4), coefList, double(coefList)), 0.001);
W64 = sdisplay(VerifiedW64);

VerifiedW65 = clean(replace(W(6,5), coefList, double(coefList)), 0.001);
W65 = sdisplay(VerifiedW65);

VerifiedW66 = clean(replace(W(6,6), coefList, double(coefList)), 0.001);
W66 = sdisplay(VerifiedW66);

VerifiedW67 = clean(replace(W(6,7), coefList, double(coefList)), 0.001);
W67 = sdisplay(VerifiedW67);

VerifiedW68 = clean(replace(W(6,8), coefList, double(coefList)), 0.001);
W68 = sdisplay(VerifiedW68);

VerifiedW69 = clean(replace(W(6,9), coefList, double(coefList)), 0.001);
W69 = sdisplay(VerifiedW69);

VerifiedW610 = clean(replace(W(6,10), coefList, double(coefList)), 0.001);
W610 = sdisplay(VerifiedW610);

VerifiedW611 = clean(replace(W(6,11), coefList, double(coefList)), 0.001);
W611 = sdisplay(VerifiedW611);

VerifiedW612 = clean(replace(W(6,12), coefList, double(coefList)), 0.001);
W612 = sdisplay(VerifiedW612);

VerifiedW71 = clean(replace(W(7,1), coefList, double(coefList)), 0.001);
W71 = sdisplay(VerifiedW71);

VerifiedW72 = clean(replace(W(7,2), coefList, double(coefList)), 0.001);
W72 = sdisplay(VerifiedW72);

VerifiedW73 = clean(replace(W(7,3), coefList, double(coefList)), 0.001);
W73 = sdisplay(VerifiedW73);

VerifiedW74 = clean(replace(W(7,4), coefList, double(coefList)), 0.001);
W74 = sdisplay(VerifiedW74);

VerifiedW75 = clean(replace(W(7,5), coefList, double(coefList)), 0.001);
W75 = sdisplay(VerifiedW75);

VerifiedW76 = clean(replace(W(7,6), coefList, double(coefList)), 0.001);
W76 = sdisplay(VerifiedW76);

VerifiedW77 = clean(replace(W(7,7), coefList, double(coefList)), 0.001);
W77 = sdisplay(VerifiedW77);

VerifiedW78 = clean(replace(W(7,8), coefList, double(coefList)), 0.001);
W78 = sdisplay(VerifiedW78);

VerifiedW79 = clean(replace(W(7,9), coefList, double(coefList)), 0.001);
W79 = sdisplay(VerifiedW79);

VerifiedW710 = clean(replace(W(7,10), coefList, double(coefList)), 0.001);
W710 = sdisplay(VerifiedW710);

VerifiedW711 = clean(replace(W(7,11), coefList, double(coefList)), 0.001);
W711 = sdisplay(VerifiedW711);

VerifiedW712 = clean(replace(W(7,12), coefList, double(coefList)), 0.001);
W712 = sdisplay(VerifiedW712);

VerifiedW81 = clean(replace(W(8,1), coefList, double(coefList)), 0.001);
W81 = sdisplay(VerifiedW81);

VerifiedW82 = clean(replace(W(8,2), coefList, double(coefList)), 0.001);
W82 = sdisplay(VerifiedW82);

VerifiedW83 = clean(replace(W(8,3), coefList, double(coefList)), 0.001);
W83 = sdisplay(VerifiedW83);

VerifiedW84 = clean(replace(W(8,4), coefList, double(coefList)), 0.001);
W84 = sdisplay(VerifiedW84);

VerifiedW85 = clean(replace(W(8,5), coefList, double(coefList)), 0.001);
W85 = sdisplay(VerifiedW85);

VerifiedW86 = clean(replace(W(8,6), coefList, double(coefList)), 0.001);
W86 = sdisplay(VerifiedW86);

VerifiedW87 = clean(replace(W(8,7), coefList, double(coefList)), 0.001);
W87 = sdisplay(VerifiedW87);

VerifiedW88 = clean(replace(W(8,8), coefList, double(coefList)), 0.001);
W88 = sdisplay(VerifiedW88);

VerifiedW89 = clean(replace(W(8,9), coefList, double(coefList)), 0.001);
W89 = sdisplay(VerifiedW89);

VerifiedW810 = clean(replace(W(8,10), coefList, double(coefList)), 0.001);
W810 = sdisplay(VerifiedW810);

VerifiedW811 = clean(replace(W(8,11), coefList, double(coefList)), 0.001);
W811 = sdisplay(VerifiedW811);

VerifiedW812 = clean(replace(W(8,12), coefList, double(coefList)), 0.001);
W812 = sdisplay(VerifiedW812);

VerifiedW91 = clean(replace(W(9,1), coefList, double(coefList)), 0.001);
W91 = sdisplay(VerifiedW91);

VerifiedW92 = clean(replace(W(9,2), coefList, double(coefList)), 0.001);
W92 = sdisplay(VerifiedW92);

VerifiedW93 = clean(replace(W(9,3), coefList, double(coefList)), 0.001);
W93 = sdisplay(VerifiedW93);

VerifiedW94 = clean(replace(W(9,4), coefList, double(coefList)), 0.001);
W94 = sdisplay(VerifiedW94);

VerifiedW95 = clean(replace(W(9,5), coefList, double(coefList)), 0.001);
W95 = sdisplay(VerifiedW95);

VerifiedW96 = clean(replace(W(9,6), coefList, double(coefList)), 0.001);
W96 = sdisplay(VerifiedW96);

VerifiedW97 = clean(replace(W(9,7), coefList, double(coefList)), 0.001);
W97 = sdisplay(VerifiedW97);

VerifiedW98 = clean(replace(W(9,8), coefList, double(coefList)), 0.001);
W98 = sdisplay(VerifiedW98);

VerifiedW99 = clean(replace(W(9,9), coefList, double(coefList)), 0.001);
W99 = sdisplay(VerifiedW99);

VerifiedW910 = clean(replace(W(9,10), coefList, double(coefList)), 0.001);
W910 = sdisplay(VerifiedW910);

VerifiedW911 = clean(replace(W(9,11), coefList, double(coefList)), 0.001);
W911 = sdisplay(VerifiedW911);

VerifiedW912 = clean(replace(W(9,12), coefList, double(coefList)), 0.001);
W912 = sdisplay(VerifiedW912);

VerifiedW101 = clean(replace(W(10,1), coefList, double(coefList)), 0.001);
W101 = sdisplay(VerifiedW101);

VerifiedW102 = clean(replace(W(10,2), coefList, double(coefList)), 0.001);
W102 = sdisplay(VerifiedW102);

VerifiedW103 = clean(replace(W(10,3), coefList, double(coefList)), 0.001);
W103 = sdisplay(VerifiedW103);

VerifiedW104 = clean(replace(W(10,4), coefList, double(coefList)), 0.001);
W104 = sdisplay(VerifiedW104);

VerifiedW105 = clean(replace(W(10,5), coefList, double(coefList)), 0.001);
W105 = sdisplay(VerifiedW105);

VerifiedW106 = clean(replace(W(10,6), coefList, double(coefList)), 0.001);
W106 = sdisplay(VerifiedW106);

VerifiedW107 = clean(replace(W(10,7), coefList, double(coefList)), 0.001);
W107 = sdisplay(VerifiedW107);

VerifiedW108 = clean(replace(W(10,8), coefList, double(coefList)), 0.001);
W108 = sdisplay(VerifiedW108);

VerifiedW109 = clean(replace(W(10,9), coefList, double(coefList)), 0.001);
W109 = sdisplay(VerifiedW109);

VerifiedW1010 = clean(replace(W(10,10), coefList, double(coefList)), 0.001);
W1010 = sdisplay(VerifiedW1010);

VerifiedW1011 = clean(replace(W(10,11), coefList, double(coefList)), 0.001);
W1011 = sdisplay(VerifiedW1011);

VerifiedW1012 = clean(replace(W(10,12), coefList, double(coefList)), 0.001);
W1012 = sdisplay(VerifiedW1012);

VerifiedW111 = clean(replace(W(11,1), coefList, double(coefList)), 0.001);
W111 = sdisplay(VerifiedW111);

VerifiedW112 = clean(replace(W(11,2), coefList, double(coefList)), 0.001);
W112 = sdisplay(VerifiedW112);

VerifiedW113 = clean(replace(W(11,3), coefList, double(coefList)), 0.001);
W113 = sdisplay(VerifiedW113);

VerifiedW114 = clean(replace(W(11,4), coefList, double(coefList)), 0.001);
W114 = sdisplay(VerifiedW114);

VerifiedW115 = clean(replace(W(11,5), coefList, double(coefList)), 0.001);
W115 = sdisplay(VerifiedW115);

VerifiedW116 = clean(replace(W(11,6), coefList, double(coefList)), 0.001);
W116 = sdisplay(VerifiedW116);

VerifiedW117 = clean(replace(W(11,7), coefList, double(coefList)), 0.001);
W117 = sdisplay(VerifiedW117);

VerifiedW118 = clean(replace(W(11,8), coefList, double(coefList)), 0.001);
W118 = sdisplay(VerifiedW118);

VerifiedW119 = clean(replace(W(11,9), coefList, double(coefList)), 0.001);
W119 = sdisplay(VerifiedW119);

VerifiedW1110 = clean(replace(W(11,10), coefList, double(coefList)), 0.001);
W1110 = sdisplay(VerifiedW1110);

VerifiedW1111 = clean(replace(W(11,11), coefList, double(coefList)), 0.001);
W1111 = sdisplay(VerifiedW1111);

VerifiedW1112 = clean(replace(W(11,12), coefList, double(coefList)), 0.001);
W1112 = sdisplay(VerifiedW1112);

VerifiedW121 = clean(replace(W(12,1), coefList, double(coefList)), 0.001);
W121 = sdisplay(VerifiedW121);

VerifiedW122 = clean(replace(W(12,2), coefList, double(coefList)), 0.001);
W122 = sdisplay(VerifiedW122);

VerifiedW123 = clean(replace(W(12,3), coefList, double(coefList)), 0.001);
W123 = sdisplay(VerifiedW123);

VerifiedW124 = clean(replace(W(12,4), coefList, double(coefList)), 0.001);
W124 = sdisplay(VerifiedW124);

VerifiedW125 = clean(replace(W(12,5), coefList, double(coefList)), 0.001);
W125 = sdisplay(VerifiedW125);

VerifiedW126 = clean(replace(W(12,6), coefList, double(coefList)), 0.001);
W126 = sdisplay(VerifiedW126);

VerifiedW127 = clean(replace(W(12,7), coefList, double(coefList)), 0.001);
W127 = sdisplay(VerifiedW127);

VerifiedW128 = clean(replace(W(12,8), coefList, double(coefList)), 0.001);
W128 = sdisplay(VerifiedW128);

VerifiedW129 = clean(replace(W(12,9), coefList, double(coefList)), 0.001);
W129 = sdisplay(VerifiedW129);

VerifiedW1210 = clean(replace(W(12,10), coefList, double(coefList)), 0.001);
W1210 = sdisplay(VerifiedW1210);

VerifiedW1211 = clean(replace(W(12,11), coefList, double(coefList)), 0.001);
W1211 = sdisplay(VerifiedW1211);

VerifiedW1212 = clean(replace(W(12,12), coefList, double(coefList)), 0.001);
W1212 = sdisplay(VerifiedW1212);

W = [W11, W12, W13, W14, W15, W16, W17, W18, W19, W110, W111, W112;
     W21, W22, W23, W24, W25, W26, W27, W28, W29, W210, W211, W212;
     W31, W32, W33, W34, W35, W36, W37, W38, W39, W310, W311, W312;
     W41, W42, W43, W44, W45, W46, W47, W48, W49, W410, W411, W412;
     W51, W52, W53, W54, W55, W56, W57, W58, W59, W510, W511, W512;
     W61, W62, W63, W64, W65, W66, W67, W68, W69, W610, W611, W612;
     W71, W72, W73, W74, W75, W76, W77, W78, W79, W710, W711, W712;
     W81, W82, W83, W84, W85, W86, W87, W88, W89, W810, W811, W812;
     W91, W92, W93, W94, W95, W96, W97, W98, W99, W910, W911, W912;
     W101, W102, W103, W104, W105, W106, W107, W108, W109, W1010, W1011, W1012;
     W111, W112, W113, W114, W115, W116, W117, W118, W119, W1110, W1111, W1112;
     W121, W122, W123, W124, W125, W126, W127, W128, W129, W1210, W1211, W1212];
